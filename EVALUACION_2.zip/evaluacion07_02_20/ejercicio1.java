package evaluacion07_02_20;

import java.util.Scanner;

public class ejercicio1 {

	private static Scanner sc;

	public static void main (String args[]) {	
		sc = new Scanner(System.in);
		
		int ntarjeta;
		int tusuario;
		int saldo;
		int op=0;
				
		
		System.out.println("Ingrese datos para crear nuevo usuario:");
		System.out.println("Numero de tarjeta:");
		ntarjeta=sc.nextInt();
		
		System.out.println("*************************************");
		
		System.out.println("Tipo de usuario:");
		System.out.println("1.Comun");
		System.out.println("2.TNE");
		System.out.println("3.Bip:");
		tusuario=sc.nextInt();
		
		System.out.println("*************************************");
		
		if(tusuario==1) {
			System.out.println("Selecciono tipo de usuario comun");
			}
		if(tusuario==2) {
			System.out.println("Selecciono tipo de usuario TNE");
		}
		
		if(tusuario==3) {
			System.out.println("Selecciono tipo de usuario Bip");
		}
		
		System.out.println("*************************************");
		
		System.out.println("Su saldo actual es :$750");
		
		
		System.out.println("*************************************");
		
		System.out.println("Usted tiene $0 de descuento por tiempo sin actividad:");
		
		System.out.println("*************************************");
		
		while (op!=5) {
			
			System.out.println("*************************************");
		
		System.out.println("¿Que desea hacer?");
		System.out.println("1.Realizar abono");
		System.out.println("2.Descuento por viaje");
		System.out.println("3.Consultar saldo");
		System.out.println("4.Verificar cuenta");
		System.out.println("5.salir");
		
		op = sc.nextInt();
		
		
		
		
		switch(op) {
		case 1:
			abonar();
		break;
		
		case 2:
			descuento();
		break;
		
		case 3:
			saldo();
		break;
		
		case 4:
			verificar();
		break;
		
		case 5:
			salir();
		break;
			default:
				
		}
		
		}
}
	
	
	public static void  abonar() {
		System.out.println("Ingresa monto a abonar:" );
		int abonar = sc.nextInt();
		System.out.println("¡Operacion exitosa!" );
	}
	
	public static void  descuento() {
		System.out.println("Usted tienen un descuento de $1.000 en su primer viaje" );
		
		}
	
	public static void  saldo() {
		System.out.println("Su saldo actual es: ");
		System.out.println("¡Operacion exitosa!" );
		
		}
	
	public static void  verificar() {
		boolean ac = false;
		System.out.println("Su cuenta actualmente se encuentra:" +ac);
		}
	
	public static void  salir() {
			}
}
