package ejercicio07_02_20_eje3;

public class automovilbebe extends automovilp {

	automovilbebe() {
		super();
		// TODO Auto-generated constructor stub
	}

	automovilbebe(String marca, String modelo, int año, double preciofinal) {
		super(marca, modelo, año, preciofinal);
		// TODO Auto-generated constructor stub
	}

	
	
	
}
