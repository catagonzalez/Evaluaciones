package ejercicio07_02_20_eje3;

import java.util.Scanner;

public class mainp {
	private static Scanner sc;
	public static void main (String args []) {
		
		sc = new Scanner(System.in);
		int n=0;
		final int n2=100000;
		float porcentaje;
		float rf;
		float rf2;
		
		
		automovilbebe nuevo = new automovilbebe();
		System.out.print("Ingrese datos del nuevo auto:" );
		System.out.print("\nMarca:" );
		nuevo.marca=sc.next();
		System.out.print("Modelo:" );
		nuevo.modelo=sc.next();
		System.out.print("Año:" );
		nuevo.año=sc.nextInt();
		System.out.print("Ingrese precio:");
		n=sc.nextInt();
		porcentaje= n+n2;
		rf=(porcentaje*24)/100;
		rf2=porcentaje-rf;
		System.out.print("Precio final:"+rf2);
		nuevo.preciofinal=sc.nextDouble();

	
	
	
	}
	
	
}
