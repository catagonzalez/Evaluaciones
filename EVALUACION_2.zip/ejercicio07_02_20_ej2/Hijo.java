package ejercicio07_02_20_ej2;

public class Hijo extends Padre{

	public Hijo() {
		super();
		}

	Hijo(String rut, String apellidop, String apellidom, String direccion, int fono, String email) {
		super(rut, apellidop, apellidom, direccion, fono, email);
		// TODO Auto-generated constructor stub
	}

	Hijo(String rut, String nombre, String apellidop, String apellidom, String cargo) {
		super(rut, nombre, apellidop, apellidom, cargo);
		// TODO Auto-generated constructor stub
	}

	
	
}