package ejercicio07_02_20_ej2;

public class Padre {

	String rut;
	String nombre;
	String apellidop;
	String apellidom;
	String cargo;
	String direccion;
	int fono;
	String email;
	
	public Padre(){ // constructor vacio
		super();
		}

	Padre(String rut, String nombre, String apellidop, String apellidom, String cargo) {//constructor 1
		super();
		this.rut = rut;
		this.nombre = nombre;
		this.apellidop = apellidop;
		this.apellidom = apellidom;
		this.cargo = cargo;
	}

	Padre(String rut, String apellidop, String apellidom, String direccion, int fono, String email) {//constructor 2
		super();
		this.rut = rut;
		this.apellidop = apellidop;
		this.apellidom = apellidom;
		this.direccion = direccion;
		this.fono = fono;
		this.email = email;
	}

	
	
}
	
	