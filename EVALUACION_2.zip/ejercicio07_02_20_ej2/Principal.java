package ejercicio07_02_20_ej2;

import java.util.Scanner;

import ejercicio_padre_hijo.Hijo;

public class Principal {
	private static Scanner sc;
	
	public static void main (String args[]) {
		
		sc = new Scanner(System.in);
		
		Hijo empleado = new Hijo ();
		System.out.print("Ingrese datos del empleado:" );
		System.out.print("\nRUT:" );
		empleado.rut=sc.next();
		System.out.print("Nombre:" );
		empleado.nombre=sc.next();
		System.out.print("Apellido Paterno:" );
		empleado.apellidop=sc.next();
		System.out.print("Apellido Materno:" );
		empleado.apellidom=sc.next();
		System.out.print("Cargo:" );
		empleado.cargo=sc.next();
		System.out.print("Direccion:" );
		empleado.direccion=sc.next();
		System.out.print("Fono:" );
		empleado.fono=sc.nextInt();
		System.out.print("Email:" );
		empleado.email=sc.next();
		
		
		System.out.println("");
		System.out.println("**************************************");
		System.out.println("");
		
		System.out.println("Usted ingreso los siguientes datos:"+"\nRUT:"+empleado.rut+"\nNombre:"+empleado.nombre+
							"\nApellido Paterno:"+empleado.apellidop+"\nApellido Materno:"+empleado.apellidom+"\nCargo:"+empleado.cargo+
							"\nDireccion:"+empleado.direccion+"\nFono:"+empleado.fono+"\nEmail:"+empleado.email);
		
		
		
	}
	
	}
