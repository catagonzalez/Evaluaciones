package ejercicio07_02_20_ej4;

public class epublico extends empleado {

	
	String municipalidad;
	String departamento;
	
	public epublico() {
		super();
		// TODO Auto-generated constructor stub
	}
	epublico(String rut, String nombre, String apellidos, String direccion, int telefono, double sueldo,
			String comuna, String empresa) {
		super(rut, nombre, apellidos, direccion, telefono, sueldo, comuna, empresa);
		// TODO Auto-generated constructor stub
	}
	
	public epublico(String municipalidad, String departamento) {
		super();
		this.municipalidad = municipalidad;
		this.departamento = departamento;
	}
	public String getMunicipalidad() {
		return municipalidad;
	}
	public void setMunicipalidad(String municipalidad) {
		this.municipalidad = municipalidad;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	
	

	
	
	
	
}
