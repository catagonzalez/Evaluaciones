package ejercicio07_02_20_ej4;



public class persona {

	
	public static void main (String args[]) {
		
		
		epublico epublicoo = new epublico ("15242356-6", "Fernando","Mellado Salinas", "Los Laureles 45",
				945281947, 780000, "Los Alamos", "Administrativo");
		
		epublico epublicooo = new epublico ("Los Alamos", "Administrativo");
		
		
		eprivado eprivadoo = new eprivado ("12345678-7", "Francisco","Risopatron De Lourdes", "Juan Bosco 1786",
				976834616, 600000, "Las Condes", "Gerencia");
		
		
		System.out.println("Datos empleado publico:"+"\nRUT:"+epublicoo.getRut()+"\nNombre:"+epublicoo.getNombre()+
				"\nApellidos:" +epublicoo.getApellidos()+"\nDireccion:"+epublicoo.getDireccion()+
				"\nTelefono:"+epublicoo.getTelefono()+"\nSueldo:"+epublicoo.getSueldo()+
				"\nMunicipalidad:"+epublicooo.getMunicipalidad()+"\nCargo:"+epublicooo.getDepartamento());
		
		System.out.println("");
		
		System.out.println("Datos empleado privado:"+"\nRUT:"+eprivadoo.getRut()+"\nNombre:"+eprivadoo.getNombre()+
				"\nApellidos:" +eprivadoo.getApellidos()+"\nDireccion:"+eprivadoo.getDireccion()+
				"\nTelefono:"+eprivadoo.getTelefono()+"\nSueldo:"+eprivadoo.getSueldo()+
				"\nComuna:"+eprivadoo.getComuna()+"\nEmpresa:"+eprivadoo.getEmpresa());


		
		
		
	}
	
}
