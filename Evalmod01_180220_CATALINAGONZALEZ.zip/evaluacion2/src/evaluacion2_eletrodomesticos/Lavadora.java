package evaluacion2_eletrodomesticos;

public class Lavadora extends Electrodomestico {

	int carga;
	protected final static int Carga_def=30;

	
	public Lavadora() {
		super();
	}


	public Lavadora(int preciobase, String peso) {
		super(preciobase, peso);
		// TODO Auto-generated constructor stub
	}


	public Lavadora(int preciobase, String color, String consumoenergetico, int peso) {
		super(preciobase, color, consumoenergetico, peso);
		// TODO Auto-generated constructor stub
	}


	public Lavadora(int carga) {
		super();
		this.carga = carga;
	}


	public int getCarga() {
		return carga;
	}


	public void setCarga(int carga) {
		this.carga = carga;
	}
	
	public int preciofinal() {
		int precio=preciofinal();
		if(carga>30) {
			preciobase=preciobase+40000;
		}
	}
	
	
	
	
}
