package evaluacion2_eletrodomesticos;

public class Television extends Electrodomestico {
	//variables
	int resolucion;
	boolean sintonizador;
	
	//constantes
	protected final static int Resolucion_def=20;
	
	public Television() {
		super();
	}

	public Television(int preciobase2, String peso2) {
		super(preciobase2, peso2);
		// TODO Auto-generated constructor stub
	}

	
	
	public Television(int resolucion, boolean sintonizador) {
		super();
		this.resolucion = resolucion;
		this.sintonizador = sintonizador;
	}

	public Television(int preciobase, String color, String consumoenergetico, int peso) {
		super(preciobase, color, consumoenergetico, peso);
		// TODO Auto-generated constructor stub
	}

	public int getResolucion() {
		return resolucion;
	}

	public void setResolucion(int resolucion) {
		this.resolucion = resolucion;
	}

	public boolean isSintonizador() {
		return sintonizador;
	}

	public void setSintonizador(boolean sintonizador) {
		this.sintonizador = sintonizador;
	}
	
	
	public double preciofinal() {
		double precio=super.preciofinal();
		if(resolucion>40) {
			precio+=preciobase*0.3;
		}
		
		if(sintonizador) {
			precio+=40000;
		}
		return precio;
		}
	}
		
	

