package evaluacion2_eletrodomesticos;

import java.util.Scanner;

public class Ejecutable {
	private static Scanner sc;
	public static void main (String args[]) {
		sc = new Scanner(System.in);
		
		Electrodomestico arreglo[] = new Electrodomestico[10];
		arreglo[0]=new Electrodomestico(100000,"blanco","f",5);
		arreglo[1]=new Lavadora(100000,"blanco","f",5);
		arreglo[2]=new Television(80000,"gris","a",10);
		arreglo[3]=new Electrodomestico(100000,"negro","a",5);
		arreglo[4]=new Lavadora(100000,"blanco","f",5);
		arreglo[5]=new Television(100000,"azul","d",5);
		arreglo[6]=new Electrodomestico(100000,"blanco","f",5);
		arreglo[7]=new Lavadora(100000,"blanco","f",5);
		arreglo[8]=new Electrodomestico(100000,"blanco","f",20);
		arreglo[9]=new Television(100000,"blanco","f",10);
		
		double sumaElectrodomesticos=0;
        double sumaTelevisores=0;
        double sumaLavadoras=0;
        
        for(int i=0;i<arreglo.length;i++) {
        	if(arreglo[i]instanceof Electrodomestico) {
        		sumaElectrodomesticos+=arreglo[i].preciofinal();
        		}
        	if(arreglo[i]instanceof Lavadora) {
        		sumaLavadoras+=arreglo[i].preciofinal();
        		}
        	if(arreglo[i]instanceof Television) {
        		sumaTelevisores+=arreglo[i].preciofinal();
        		}
        }
        
        System.out.println("La suma del precio de los electrodomesticos es de "+sumaElectrodomesticos);
        System.out.println("La suma del precio de las lavadoras es de "+sumaLavadoras);
        System.out.println("La suma del precio de las televisiones es de "+sumaTelevisores);
	}
	
}
