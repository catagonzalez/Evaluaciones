package evaluacion2_eletrodomesticos;

public class Electrodomestico {

	//variables
	int preciobase;
	String color;
	String consumoenergetico;
	int peso;
	
	//constantes
	protected final static int Preciobase_def=1000000;
	protected final static String color_def="blanco";
	protected final static String Consumoenergetico_def="f";
	protected final static int Peso_def= 5;
	
	
	
	
	private char comprobarconsumoenergetico;
	private String comprobarcolor;
	
	public Electrodomestico() {
		super();
	}

	

	public Electrodomestico(int preciobase, String color, String consumoenergetico, int peso) {
		super();
		this.preciobase = preciobase;
		this.color = color;
		this.consumoenergetico = consumoenergetico;
		this.peso = peso;
	}

	public Electrodomestico(int preciobase2, String peso2) {
		// TODO Auto-generated constructor stub
	}



	public int getPreciobase() {
		return preciobase;
	}

	public void setPreciobase(int preciobase) {
		this.preciobase = preciobase;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getConsumoenergetico() {
		return consumoenergetico;
	}

	public void setConsumoenergetico(String consumoenergetico) {
		this.consumoenergetico = consumoenergetico;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}
	
	
	public void comprobarconsumoenergetico(char comprobarconsumoenergetico) {
		
		}
	
	
	public void comprobarcolor(String comprobarcolor) {
		String colores[]={"blanco","negro","rojo","azul","gris"};
		boolean colorencontrado = false;
		for(int i=0;i<colores.length &&!colorencontrado;i++) {
			if(colores[i].equals(color)) {
				colorencontrado=true;
			}
		}
		
		if(colorencontrado) {
			this.color=color;
			}
		else {
			this.color=color_def;
		}
	}
	
	
	public double preciofinal() {
		double precio=0;
		
		switch(consumoenergetico){
		case "A":
			precio+=85000;
			break;
		case "B":
			precio+=70000;
			break;
		case "C":
			precio+=50000;
			break;
		case "D":
			precio+=40000;
			break;
		case "E":
			precio+=25000;
			break;
		case "F":
			precio+=8500;
			break;
			}
		if(peso>=0&& peso<19){
			precio+=8500;
			} else if (peso>=20 && peso<49){
			precio+=40000;	
			} else if (peso>=50 && peso <=79) {
			precio+=70000;
			} else if (peso>=80) {
			precio+=85000;
			}
		return precio;
		}
	
	
}